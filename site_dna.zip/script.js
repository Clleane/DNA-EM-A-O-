const perguntas = [
    { pergunta: "Qual a função principal do DNA?", opcoes: ["Armazenar informações genéticas", "Produzir energia", "Transportar oxigênio"], correta: 0 },
    { pergunta: "Qual base nitrogenada não está presente no DNA?", opcoes: ["Timina", "Uracila", "Guanina"], correta: 1 },
    { pergunta: "O DNA tem formato de:", opcoes: ["Dupla hélice", "Cadeia simples", "Circular"], correta: 0 }
];

let indiceAtual = 0;

function carregarPergunta() {
    const perguntaDiv = document.getElementById("pergunta");
    const opcoesDiv = document.getElementById("opcoes");
    const botaoProxima = document.getElementById("proxima");
    
    perguntaDiv.innerText = perguntas[indiceAtual].pergunta;
    opcoesDiv.innerHTML = "";

    perguntas[indiceAtual].opcoes.forEach((opcao, index) => {
        const botao = document.createElement("button");
        botao.innerText = opcao;
        botao.onclick = () => verificarResposta(index);
        opcoesDiv.appendChild(botao);
    });

    botaoProxima.style.display = "none";
}

function verificarResposta(indice) {
    const resultado = document.getElementById("resultado");
    if (indice === perguntas[indiceAtual].correta) {
        resultado.innerText = "Correto!";
        document.getElementById("proxima").style.display = "block";
    } else {
        resultado.innerText = "Errado! Tente novamente.";
    }
}

document.getElementById("proxima").onclick = () => {
    indiceAtual++;
    if (indiceAtual < perguntas.length) {
        carregarPergunta();
        document.getElementById("resultado").innerText = "";
    } else {
        document.getElementById("quiz").innerHTML = "<h2>Parabéns! Você concluiu o quiz.</h2>";
    }
};

carregarPergunta();
